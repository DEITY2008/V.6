// THEPKUB 4WD - ESP32 Firmware v6  (Bluetooth Classic "THEP_4WD")
// Protocol (newline-terminated, 115200 USB or Bluetooth SPP):
//  M,l,r  wheel L/R -100..100 (20Hz heartbeat)   S  hard stop+brake   G  send config
//  T,n    test motor n(0-3) 0.7s     C,n,side,inv  motor config (saved)   X  reset motors
//  K,l,r  trim 50..100 (saved)       P,n  wiring 0=A 1=B then reboot
//  A,n    launch ramp 3..30 (higher = more punch, lower = more grip) (saved)
//  F/B/L/R test from terminal         V  version
// Needs arduino-esp32 core 2.x or 3.x. Lift the car off the ground for first test.
#include "BluetoothSerial.h"
#include <Preferences.h>

BluetoothSerial SerialBT;
Preferences prefs;

// motor m uses PINS[2m] (forward) and PINS[2m+1] (reverse). Never GPIO34-39 (input only).
const int PROFILES[2][8] = {
  {18, 19, 21, 22, 33, 32, 26, 27},   // A: original wiring
  {25, 33, 27, 26, 16, 17, 18, 19}    // B: Fritzing wiring
};
int PINS[8];

const int MIN_DUTY = 90;       // L298N drops ~2V: lowest duty that moves the car
const int MAX_DUTY = 255;
int RAMP_UP = 12;              // per 10ms (A command). 12 = 0->full in ~210ms
const int RAMP_DOWN = 30;
const unsigned long FAILSAFE_MS = 500;
const unsigned long BRAKE_MS = 250;     // active brake (IN1=IN2=HIGH) after stop
const int PWM_FREQ = 5000, PWM_RES = 8;
const char FW[] = "6.0";

uint8_t invMask = 0, sideMask = 0x0C;   // bit m: inverted / on right side
int gainL = 100, gainR = 100, profile = 0;
int tgtL = 0, tgtR = 0;
float curL = 0, curR = 0;
unsigned long lastCmd = 0, lastRamp = 0, lastTele = 0, brakeUntil = 0, testUntil = 0;
int testMotor = -1;
bool moving = false, fsSent = false;
volatile bool linkClosed = false;
String lineBT, lineUSB;

void pwmSetup(int i) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(PINS[i], PWM_FREQ, PWM_RES);
#else
  ledcSetup(i, PWM_FREQ, PWM_RES); ledcAttachPin(PINS[i], i);
#endif
}
void pwmOut(int i, int duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PINS[i], duty);
#else
  ledcWrite(i, duty);
#endif
}

float pctToDuty(int p) {
  if (!p) return 0;
  float d = MIN_DUTY + (float)(MAX_DUTY - MIN_DUTY) * abs(p) / 100.0f;
  return p > 0 ? d : -d;
}

// ramp with traction limit; clamps at 0 on direction change, then kick-starts
float approach(float c, float t) {
  if (c * t < 0) return fabsf(c) <= RAMP_DOWN ? 0 : c + (c > 0 ? -RAMP_DOWN : RAMP_DOWN);
  if (c == 0 && t != 0) c = t > 0 ? MIN_DUTY : -MIN_DUTY;
  float d = t - c;
  float lim = fabsf(t) > fabsf(c) ? RAMP_UP : RAMP_DOWN;
  if (d > lim) c += lim; else if (d < -lim) c -= lim; else c = t;
  return c;
}

void writeMotor(int m, int v, bool brake = false) {
  if (brake) { pwmOut(2 * m, 255); pwmOut(2 * m + 1, 255); return; }
  if ((invMask >> m) & 1) v = -v;
  pwmOut(2 * m,     constrain(v, 0, 255));
  pwmOut(2 * m + 1, constrain(-v, 0, 255));
}

void stopAll() {                       // immediate hard stop with brake
  tgtL = tgtR = 0; curL = curR = 0; testMotor = -1;
  brakeUntil = millis() + BRAKE_MS; moving = false;
  for (int m = 0; m < 4; m++) writeMotor(m, 0, true);
}

void outputs() {
  unsigned long now = millis();
  if (testMotor >= 0 && now > testUntil) testMotor = -1;
  bool brake = testMotor < 0 && now < brakeUntil;
  for (int m = 0; m < 4; m++) {
    int v;
    if (testMotor >= 0) v = (m == testMotor) ? 180 : 0;
    else {
      bool r = (sideMask >> m) & 1;
      v = (int)(r ? curR * gainR / 100.0f : curL * gainL / 100.0f);
    }
    writeMotor(m, v, brake);
  }
}

void out(const String &s) { if (SerialBT.hasClient()) SerialBT.println(s); Serial.println(s); }

void sendCfg() {
  String s = "CFG,";
  for (int m = 0; m < 4; m++) s += String((invMask >> m) & 1) + ",";
  for (int m = 0; m < 4; m++) s += String((sideMask >> m) & 1) + ",";
  s += String(gainL) + "," + gainR + "," + profile + "," + RAMP_UP;
  out(s);
}

void setDrive(int l, int r) {
  tgtL = constrain(l, -100, 100); tgtR = constrain(r, -100, 100);
  lastCmd = millis(); fsSent = false;
  if (tgtL || tgtR) brakeUntil = 0;
}

void handleLine(String s) {
  s.trim();
  if (!s.length()) return;
  char c = toupper(s[0]);
  const char *a = s.c_str() + 1;
  int x, y, z;
  switch (c) {
    case 'M': if (sscanf(a, ",%d,%d", &x, &y) == 2) setDrive(x, y); break;
    case 'S': stopAll(); break;
    case 'T': if (sscanf(a, ",%d", &x) == 1 && x >= 0 && x < 4 && !tgtL && !tgtR) { testMotor = x; testUntil = millis() + 700; } break;
    case 'C':
      if (sscanf(a, ",%d,%d,%d", &x, &y, &z) == 3 && x >= 0 && x < 4) {
        if (y) sideMask |= 1 << x; else sideMask &= ~(1 << x);
        if (z) invMask  |= 1 << x; else invMask  &= ~(1 << x);
        prefs.putUChar("inv5", invMask); prefs.putUChar("side5", sideMask);
        stopAll(); sendCfg();
      } break;
    case 'X':
      invMask = 0; sideMask = 0x0C;
      prefs.putUChar("inv5", invMask); prefs.putUChar("side5", sideMask);
      stopAll(); sendCfg(); break;
    case 'K':
      if (sscanf(a, ",%d,%d", &x, &y) == 2) {
        gainL = constrain(x, 50, 100); gainR = constrain(y, 50, 100);
        prefs.putUChar("gl", gainL); prefs.putUChar("gr", gainR); sendCfg();
      } break;
    case 'A':
      if (sscanf(a, ",%d", &x) == 1) { RAMP_UP = constrain(x, 3, 30); prefs.putUChar("ru", RAMP_UP); sendCfg(); } break;
    case 'P':
      if (sscanf(a, ",%d", &x) == 1 && (x == 0 || x == 1)) {
        prefs.putUChar("pf5", x); stopAll(); delay(300); ESP.restart();
      } break;
    case 'G': sendCfg(); break;
    case 'V': out(String("V,") + FW); break;
    default:
      if (s.length() == 1) {
        if (c == 'F') setDrive(60, 60); else if (c == 'B') setDrive(-60, -60);
        else if (c == 'L') setDrive(-60, 60); else if (c == 'R') setDrive(60, -60);
      }
  }
}

void readStream(Stream &st, String &buf) {
  while (st.available()) {
    char ch = st.read();
    if (ch == '\n' || ch == '\r') { handleLine(buf); buf = ""; }
    else if (buf.length() < 32) buf += ch;
    else buf = "";                       // overlong garbage -> drop line
  }
}

void btEvent(esp_spp_cb_event_t e, esp_spp_cb_param_t *) {
  if (e == ESP_SPP_CLOSE_EVT) linkClosed = true;
}

void setup() {
  Serial.begin(115200);
  prefs.begin("thep", false);
  invMask = prefs.getUChar("inv5", 0);
  sideMask = prefs.getUChar("side5", 0x0C);
  gainL = constrain(prefs.getUChar("gl", 100), 50, 100);
  gainR = constrain(prefs.getUChar("gr", 100), 50, 100);
  RAMP_UP = constrain(prefs.getUChar("ru", 12), 3, 30);
  profile = prefs.getUChar("pf5", 0); if (profile > 1) profile = 0;
  for (int i = 0; i < 8; i++) PINS[i] = PROFILES[profile][i];
  for (int i = 0; i < 8; i++) { pwmSetup(i); pwmOut(i, 0); }
  SerialBT.register_callback(btEvent);
  if (!SerialBT.begin("THEP_4WD")) Serial.println("Bluetooth init FAILED");
  Serial.printf("THEPKUB v%s ready, wiring %c\n", FW, profile ? 'B' : 'A');
}

void loop() {
  readStream(SerialBT, lineBT);
  readStream(Serial, lineUSB);
  if (linkClosed) { linkClosed = false; stopAll(); }

  unsigned long now = millis();
  if ((tgtL || tgtR) && now - lastCmd > FAILSAFE_MS) {
    stopAll();
    if (!fsSent) { fsSent = true; out("FS"); }
  }
  if (now - lastRamp >= 10) {
    lastRamp = now;
    curL = approach(curL, pctToDuty(tgtL));
    curR = approach(curR, pctToDuty(tgtR));
    if (curL || curR) moving = true;
    else if (moving) { moving = false; brakeUntil = now + BRAKE_MS; }   // coasted to 0 -> brake
    outputs();
  }
  if (now - lastTele >= 200) {
    lastTele = now;
    if (SerialBT.hasClient()) SerialBT.printf("T,%d,%d\n", tgtL, tgtR);
  }
}
