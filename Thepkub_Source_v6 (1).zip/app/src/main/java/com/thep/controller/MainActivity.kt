package com.thep.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val BG = 0xFF0A0C10.toInt()
private const val PANEL = 0xFF151A21.toInt()
private const val LINE = 0xFF2A323D.toInt()
private const val AMBER = 0xFFFFB300.toInt()
private const val CYAN = 0xFF22D3EE.toInt()
private const val RED = 0xFFFF3B30.toInt()
private const val GREEN = 0xFF34D399.toInt()
private const val TXT = 0xFFE6EDF3.toInt()
private const val DIM = 0xFF7B8794.toInt()

/** หน้าขับ: คันเร่งแนวตั้งซ้าย, พวงมาลัยแนวนอนขวา, ศูนย์กลางแสดงสถานะ */
@SuppressLint("ViewConstructor")
class DriveView(ctx: Context) : View(ctx) {
    @Volatile var outL = 0
    @Volatile var outR = 0
    @Volatile var linkOk = false
    var gear = 1
    var estop = false
    var invThr = false
    var invStr = false
    var deviceName = ""
    var onSetup: () -> Unit = {}
    var onDisconnect: () -> Unit = {}

    private var thr = 0f; private var str = 0f
    private var thrId = -1; private var strId = -1
    private var dispL = 0f; private var dispR = 0f
    private var last = 0L
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); textAlign = Paint.Align.CENTER }
    private val thrR = RectF(); private val strR = RectF(); private val estopR = RectF()
    private val setupR = RectF(); private val discR = RectF()
    private val gearR = Array(3) { RectF() }
    private val gearName = arrayOf("ECO", "NORMAL", "TURBO")
    private val gearCap = floatArrayOf(0.55f, 0.8f, 1f)
    private val tmp = RectF()

    private val loop = object : Runnable {
        override fun run() { step(); invalidate(); postOnAnimation(this) }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); last = System.nanoTime(); postOnAnimation(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    fun reset() { thr = 0f; str = 0f; thrId = -1; strId = -1 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val m = h * 0.06f
        thrR.set(m, m, m + h * 0.30f, h - m)
        strR.set(w - m - w * 0.36f, h * 0.5f - h * 0.17f, w - m, h * 0.5f + h * 0.17f)
        val cx = (thrR.right + strR.left) / 2f
        val gw = (strR.left - thrR.right) * 0.28f
        for (i in 0..2) gearR[i].set(cx - gw * 1.5f - 6 * d + i * (gw + 6 * d), h * 0.07f, cx - gw * 1.5f - 6 * d + i * (gw + 6 * d) + gw, h * 0.19f)
        estopR.set(cx - gw * 1.3f, h * 0.76f, cx + gw * 1.3f, h - m)
        setupR.set(w - m - w * 0.16f, m, w - m, m + h * 0.12f)
        discR.set(strR.left, m, strR.left + w * 0.14f, m + h * 0.12f)
    }

    private fun hit(r: RectF, x: Float, y: Float, pad: Float = 0f) =
        x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad

    private fun setThr(y: Float) { thr = ((thrR.centerY() - y) / (thrR.height() / 2f - 10 * d)).coerceIn(-1f, 1f) }
    private fun setStr(x: Float) { str = ((x - strR.centerX()) / (strR.width() / 2f - 10 * d)).coerceIn(-1f, 1f) }
    private fun tap() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val id = e.getPointerId(i); val x = e.getX(i); val y = e.getY(i)
                when {
                    hit(estopR, x, y, 8 * d) -> { estop = !estop; tap() }
                    hit(setupR, x, y, 8 * d) -> { reset(); onSetup() }
                    hit(discR, x, y, 8 * d) -> { reset(); onDisconnect() }
                    gearR.indexOfFirst { hit(it, x, y, 6 * d) } >= 0 -> { gear = gearR.indexOfFirst { hit(it, x, y, 6 * d) }; tap() }
                    hit(thrR, x, y, 24 * d) && thrId == -1 -> { thrId = id; setThr(y) }
                    hit(strR, x, y, 24 * d) && strId == -1 -> { strId = id; setStr(x) }
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val id = e.getPointerId(i)
                if (id == thrId) setThr(e.getY(i)) else if (id == strId) setStr(e.getX(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == thrId) { thrId = -1; thr = 0f }
                if (id == strId) { strId = -1; str = 0f }
            }
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    private fun expo(x: Float, dead: Float): Float {
        val a = abs(x); if (a < dead) return 0f
        val n = (a - dead) / (1f - dead)
        val v = 0.4f * n + 0.6f * n * n * n
        return if (x < 0f) -v else v
    }

    private fun step() {
        val now = System.nanoTime(); val dt = min(0.05f, (now - last) / 1e9f); last = now
        val cap = gearCap[gear]
        val t = expo(thr, 0.06f) * cap * (if (invThr) -1f else 1f)
        val s = expo(str, 0.08f) * (if (invStr) -1f else 1f)
        var l: Float; var r: Float
        if (abs(t) < 0.08f) { l = s * 0.85f * cap.coerceAtLeast(0.7f); r = -l }   // หมุนอยู่กับที่
        else {
            val steer = s * (0.6f + 0.4f * (1f - abs(t)))                         // ยิ่งเร็วยิ่งเลี้ยวนุ่ม
            l = t + steer * abs(t).coerceAtLeast(0.5f); r = t - steer * abs(t).coerceAtLeast(0.5f)
            val m = max(1f, max(abs(l), abs(r))); l /= m; r /= m
        }
        if (estop) { l = 0f; r = 0f }
        outL = (l * 100f).roundToInt(); outR = (r * 100f).roundToInt()
        val k = min(1f, dt * 14f)
        dispL += (l - dispL) * k; dispR += (r - dispR) * k
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        tp.textSize = size; tp.color = color; tp.textAlign = align; c.drawText(s, x, y + size * 0.35f, tp)
    }

    private fun chip(c: Canvas, r: RectF, label: String, color: Int, on: Boolean, size: Float) {
        p.style = Paint.Style.FILL; p.color = if (on) color else PANEL; c.drawRoundRect(r, 10 * d, 10 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = if (on) color else LINE; c.drawRoundRect(r, 10 * d, 10 * d, p)
        txt(c, label, r.centerX(), r.centerY(), size, if (on) BG else color)
    }

    private fun bar(c: Canvas, r: RectF, v: Float, vertical: Boolean, thumbV: Float?) {
        p.style = Paint.Style.FILL; p.color = PANEL; c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = LINE; c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.style = Paint.Style.FILL
        val a = abs(v)
        if (vertical) {
            val half = r.height() / 2f - 10 * d
            val y = r.centerY() - v * half
            p.color = if (v >= 0) AMBER else CYAN
            tmp.set(r.left + 8 * d, min(y, r.centerY()), r.right - 8 * d, max(y, r.centerY())); p.alpha = 90; c.drawRect(tmp, p); p.alpha = 255
            p.color = LINE; c.drawRect(r.left + 12 * d, r.centerY() - d, r.right - 12 * d, r.centerY() + d, p)
            if (thumbV != null) {
                val ty = r.centerY() - thumbV * half
                p.color = if (a > 0.02f) (if (thumbV >= 0) AMBER else CYAN) else TXT
                tmp.set(r.left + 4 * d, ty - 14 * d, r.right - 4 * d, ty + 14 * d); c.drawRoundRect(tmp, 10 * d, 10 * d, p)
            }
        } else {
            val half = r.width() / 2f - 10 * d
            val x = r.centerX() + v * half
            p.color = GREEN; tmp.set(min(x, r.centerX()), r.top + 8 * d, max(x, r.centerX()), r.bottom - 8 * d); p.alpha = 90; c.drawRect(tmp, p); p.alpha = 255
            p.color = LINE; c.drawRect(r.centerX() - d, r.top + 12 * d, r.centerX() + d, r.bottom - 12 * d, p)
            if (thumbV != null) {
                val tx = r.centerX() + thumbV * half
                p.color = if (abs(thumbV) > 0.02f) GREEN else TXT
                tmp.set(tx - 14 * d, r.top + 4 * d, tx + 14 * d, r.bottom - 4 * d); c.drawRoundRect(tmp, 10 * d, 10 * d, p)
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(BG)
        bar(c, thrR, thr, true, thr)
        bar(c, strR, str, false, str)
        txt(c, "THROTTLE", thrR.centerX(), thrR.top - 0f + 10 * d, 9 * d, DIM)
        txt(c, "STEER", strR.centerX(), strR.bottom + 14 * d, 10 * d, DIM)
        for (i in 0..2) chip(c, gearR[i], gearName[i], if (i == 2) RED else if (i == 0) CYAN else AMBER, gear == i, 11 * d)
        chip(c, setupR, "SETUP", AMBER, false, 11 * d)
        chip(c, discR, "EXIT", DIM, false, 11 * d)
        // กลาง: กำลัง + ล้อซ้าย/ขวา
        val cx = (thrR.right + strR.left) / 2f
        val pw = (max(abs(dispL), abs(dispR)) * 100).roundToInt()
        txt(c, "$pw", cx, h * 0.46f, h * 0.22f, if (estop) RED else TXT)
        txt(c, "% POWER", cx, h * 0.62f, 10 * d, DIM)
        for (side in 0..1) {
            val v = if (side == 0) dispL else dispR
            val bx = cx + (if (side == 0) -1 else 1) * h * 0.30f
            tmp.set(bx - 7 * d, h * 0.28f, bx + 7 * d, h * 0.66f)
            p.style = Paint.Style.FILL; p.color = PANEL; c.drawRoundRect(tmp, 6 * d, 6 * d, p)
            val mid = tmp.centerY(); val y = mid - v * tmp.height() / 2f
            p.color = if (v >= 0) AMBER else CYAN
            c.drawRect(tmp.left, min(y, mid), tmp.right, max(y, mid), p)
            txt(c, if (side == 0) "L" else "R", bx, h * 0.72f, 10 * d, DIM)
        }
        // สถานะลิงก์
        p.style = Paint.Style.FILL; p.color = if (linkOk) GREEN else AMBER; c.drawCircle(cx - 40 * d, h * 0.235f, 4 * d, p)
        txt(c, deviceName.take(14), cx + 8 * d, h * 0.235f, 9 * d, DIM)
        // E-STOP
        p.style = Paint.Style.FILL; p.color = if (estop) RED else 0xFF3A1210.toInt(); c.drawRoundRect(estopR, 14 * d, 14 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = RED; c.drawRoundRect(estopR, 14 * d, 14 * d, p)
        txt(c, if (estop) "RELEASE" else "E-STOP", estopR.centerX(), estopR.centerY(), 13 * d, if (estop) BG else RED)
    }
}

class MainActivity : Activity() {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val ui = Handler(Looper.getMainLooper())
    private val q = LinkedBlockingQueue<String>()
    private var adapter: BluetoothAdapter? = null
    @Volatile private var sock: BluetoothSocket? = null
    @Volatile private var connected = false
    @Volatile private var session = 0
    @Volatile private var lastTele = 0L
    private var lastDev: BluetoothDevice? = null
    private var devName = "-"
    private var drive: DriveView? = null
    private var screen = 0            // 0 อุปกรณ์, 1 ขับ, 2 ตั้งค่า
    private val cfg = IntArray(12)    // inv0-3, side0-3, gainL, gainR, profile, ramp
    private var afterPerm: (() -> Unit)? = null
    private var listBox: LinearLayout? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanOn = false
    private var invBtn = arrayOfNulls<Button>(4)
    private var sideBtn = arrayOfNulls<Button>(4)
    private var trimL: SeekBar? = null; private var trimR: SeekBar? = null; private var rampBar: SeekBar? = null
    private var trimTxt: TextView? = null; private var rampTxt: TextView? = null; private var profBtn: Button? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun send(s: String) { q.offer(s) }

    // ---------- UI helpers ----------
    private fun label(t: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun button(t: String, color: Int, fill: Boolean = false, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(if (fill) BG else color)
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat(); setColor(if (fill) color else PANEL); setStroke(dp(1), color)
        }
        minHeight = dp(44); minimumHeight = dp(44)
        setOnClickListener { click() }
    }

    private fun page(content: View) {
        val sv = ScrollView(this).apply { setBackgroundColor(BG); addView(content) }
        setContentView(sv)
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        showDevices()
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) { 1 -> disconnect(); 2 -> showDrive(); else -> super.onBackPressed() }
    }

    // ---------- เลือกอุปกรณ์ ----------
    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                        i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    if (d != null && !found.containsKey(d.address)) { found[d.address] = d; refreshList() }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> scanOn = false
            }
        }
    }
    private var receiverOn = false

    private fun showDevices() {
        screen = 0; immersive(false)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20)) }
        col.addView(label("THEPKUB", 34f, AMBER, true))
        col.addView(label("4WD RC CONTROLLER  v6", 11f, DIM))
        val row = LinearLayout(this)
        row.addView(button("SCAN", AMBER, true) { ensurePermissions { startScan() } }, lp(0, dp(48), 1f))
        row.addView(button("RECONNECT", CYAN) { lastDev?.let { connect(it) } ?: toast("ยังไม่เคยเชื่อมต่อ") }, lp(0, dp(48), 1f))
        col.addView(row)
        col.addView(label("จับคู่ THEP_4WD ใน Settings > Bluetooth ก่อน แล้วแตะชื่อด้านล่าง", 12f, DIM))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)
        page(col)
        ensurePermissions { loadBonded(); refreshList() }
    }

    @SuppressLint("MissingPermission")
    private fun loadBonded() {
        try { adapter?.bondedDevices?.forEach { found[it.address] = it } } catch (_: SecurityException) {}
    }

    @SuppressLint("MissingPermission")
    private fun refreshList() {
        val box = listBox ?: return
        box.removeAllViews()
        if (adapter?.isEnabled == false) { box.addView(label("Bluetooth ปิดอยู่ — เปิดก่อน", 14f, RED)); return }
        val list = found.values.sortedByDescending { isCar(it) }
        for (d in list) {
            val nm = try { d.name ?: d.address } catch (_: SecurityException) { d.address }
            box.addView(button((if (isCar(d)) "★ " else "") + nm + "\n" + d.address, if (isCar(d)) AMBER else DIM) { connect(d) }, lp(-1, dp(64)))
        }
        if (list.isEmpty()) box.addView(label("ไม่พบอุปกรณ์ — กด SCAN", 13f, DIM))
    }

    @SuppressLint("MissingPermission")
    private fun isCar(d: BluetoothDevice) = try { d.name?.contains("THEP", true) == true } catch (_: SecurityException) { false }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val a = adapter ?: return
        if (!receiverOn) {
            val f = IntentFilter(BluetoothDevice.ACTION_FOUND); f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            registerReceiver(receiver, f); receiverOn = true
        }
        try { if (a.isDiscovering) a.cancelDiscovery(); a.startDiscovery(); scanOn = true; toast("กำลังสแกน...") }
        catch (_: SecurityException) { toast("ไม่มีสิทธิ์ Bluetooth") }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        try { if (scanOn) adapter?.cancelDiscovery() } catch (_: Exception) {}
        scanOn = false
        if (receiverOn) { try { unregisterReceiver(receiver) } catch (_: Exception) {}; receiverOn = false }
    }

    private fun ensurePermissions(then: () -> Unit) {
        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isEmpty()) then() else { afterPerm = then; requestPermissions(miss.toTypedArray(), 1) }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res.all { it == PackageManager.PERMISSION_GRANTED }) afterPerm?.invoke()
        else toast("ต้องอนุญาต Bluetooth ก่อนใช้งาน")
        afterPerm = null
    }

    // ---------- การเชื่อมต่อ ----------
    @SuppressLint("MissingPermission")
    private fun openSocket(d: BluetoothDevice): BluetoothSocket {
        try {
            val s = d.createRfcommSocketToServiceRecord(SPP)
            try { s.connect(); return s } catch (_: Exception) { try { s.close() } catch (_: Exception) {} }
        } catch (_: Exception) {}
        val f = d.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(d, 1) as BluetoothSocket
        f.connect(); return f
    }

    @SuppressLint("MissingPermission")
    private fun connect(d: BluetoothDevice) {
        stopScan()
        toast("กำลังเชื่อมต่อ...")
        val gen = ++session
        closeSock()
        Thread {
            var s: BluetoothSocket? = null
            var err: Exception? = null
            for (i in 0 until 2) {
                try { adapter?.cancelDiscovery(); s = openSocket(d); break } catch (e: Exception) { err = e; Thread.sleep(400) }
            }
            if (s == null || gen != session) {
                try { s?.close() } catch (_: Exception) {}
                ui.post { toast("เชื่อมต่อไม่สำเร็จ: ${err?.message ?: "ยกเลิก"}") }
                return@Thread
            }
            sock = s; q.clear(); connected = true; lastDev = d
            devName = try { d.name ?: d.address } catch (_: SecurityException) { d.address }
            startWriter(s, gen)
            ui.post { showDrive(); ui.removeCallbacks(tick); ui.post(tick); send("V"); send("G") }
            readLoop(s.inputStream, gen)
        }.start()
    }

    private fun startWriter(s: BluetoothSocket, gen: Int) {
        Thread {
            try {
                val os = s.outputStream
                while (connected && gen == session) {
                    val m = q.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    os.write((m + "\n").toByteArray()); os.flush()
                }
            } catch (_: Exception) { lost(gen) }
        }.start()
    }

    private fun readLoop(input: InputStream, gen: Int) {
        val buf = ByteArray(256); val sb = StringBuilder()
        try {
            while (gen == session) {
                val n = input.read(buf); if (n < 0) break
                sb.append(String(buf, 0, n))
                while (true) {
                    val i = sb.indexOf("\n"); if (i < 0) break
                    val line = sb.substring(0, i).trim(); sb.delete(0, i + 1); handleLine(line)
                }
                if (sb.length > 512) sb.setLength(0)
            }
        } catch (_: Exception) {}
        lost(gen)
    }

    private fun handleLine(l: String) {
        when {
            l.startsWith("T,") -> { lastTele = System.currentTimeMillis() }
            l.startsWith("CFG,") -> {
                val p = l.substring(4).split(",")
                for (i in 0 until min(12, p.size)) cfg[i] = p[i].trim().toIntOrNull() ?: cfg[i]
                ui.post { refreshSetup() }
            }
            l.startsWith("FS") -> ui.post { toast("Failsafe: รถหยุดเอง (สัญญาณขาด)") }
        }
    }

    private fun lost(gen: Int) {
        if (gen != session || !connected) return
        connected = false; closeSock()
        ui.post { ui.removeCallbacks(tick); drive?.reset(); toast("Bluetooth หลุด"); showDevices() }
    }

    private fun closeSock() { try { sock?.close() } catch (_: Exception) {}; sock = null }

    private fun disconnect() {
        ui.removeCallbacks(tick); drive?.reset()
        send("S")
        val gen = session
        Thread { Thread.sleep(250); if (gen == session) { connected = false; session++; closeSock() } }.start()
        showDevices()
    }

    // ส่ง M 20 ครั้ง/วินาที (เป็น heartbeat) และรวมคำสั่งค้างไม่ให้คิวสะสม
    private val tick = object : Runnable {
        override fun run() {
            if (!connected) return
            val dv = drive
            val l = if (screen == 1) dv?.outL ?: 0 else 0
            val r = if (screen == 1) dv?.outR ?: 0 else 0
            if (q.isEmpty()) send("M,$l,$r")
            dv?.linkOk = System.currentTimeMillis() - lastTele < 800
            ui.postDelayed(this, 50)
        }
    }

    // ---------- หน้าขับ ----------
    private fun showDrive() {
        screen = 1; immersive(true)
        val dv = drive ?: DriveView(this).also { drive = it }
        dv.deviceName = devName
        val pr = getSharedPreferences("thep", MODE_PRIVATE)
        dv.invThr = pr.getBoolean("invThr", false); dv.invStr = pr.getBoolean("invStr", false)
        dv.onSetup = { send("S"); showSetup() }
        dv.onDisconnect = { disconnect() }
        (dv.parent as? android.view.ViewGroup)?.removeView(dv)
        setContentView(dv)
    }

    // ---------- ตั้งค่า ----------
    private fun showSetup() {
        screen = 2; immersive(false)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        col.addView(button("◀ กลับไปขับ", AMBER, true) { showDrive() }, lp(-1, dp(48)))
        col.addView(label("ทิศทางการควบคุม (แก้เมื่อรถวิ่งสลับ)", 14f, AMBER, true))
        for ((key, name) in listOf("invThr" to "หน้า/ถอย", "invStr" to "ซ้าย/ขวา")) {
            val pr = getSharedPreferences("thep", MODE_PRIVATE)
            lateinit var b: Button
            fun txt() = "$name: " + if (pr.getBoolean(key, false)) "กลับด้าน" else "ปกติ"
            b = button(txt(), CYAN) { pr.edit().putBoolean(key, !pr.getBoolean(key, false)).apply(); b.text = txt() }
            col.addView(b, lp(-1, dp(48)))
        }
        col.addView(label("มอเตอร์ (ยกรถลอยล้อก่อนทดสอบ)", 14f, AMBER, true))
        for (m in 0..3) {
            val row = LinearLayout(this); row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label("M${m + 1}", 16f, TXT, true), lp(dp(40), -2))
            row.addView(button("ทดสอบ", GREEN) { send("T,$m") }, lp(0, dp(46), 1f))
            sideBtn[m] = button("-", CYAN) { cfgMotor(m, flipSide = true) }.also { row.addView(it, lp(0, dp(46), 1f)) }
            invBtn[m] = button("-", AMBER) { cfgMotor(m, flipInv = true) }.also { row.addView(it, lp(0, dp(46), 1f)) }
            col.addView(row)
        }
        col.addView(label("ทดสอบ → ดูว่าล้อไหนหมุน แล้วกดข้าง (ซ้าย/ขวา) และทิศ (เดินหน้า/ถอย) ให้ตรง", 11f, DIM))

        col.addView(label("สมดุลแรง (ให้วิ่งตรง)", 14f, AMBER, true))
        trimTxt = label("", 12f, TXT); col.addView(trimTxt)
        trimL = seek(50, 100) { updTrim(); }.also { col.addView(it) }
        trimR = seek(50, 100) { updTrim(); }.also { col.addView(it) }
        col.addView(button("บันทึกสมดุล", GREEN) { send("K,${trimL!!.progress + 50},${trimR!!.progress + 50}") }, lp(-1, dp(46)))

        col.addView(label("กริป ⇄ แรงออกตัว", 14f, AMBER, true))
        rampTxt = label("", 12f, TXT); col.addView(rampTxt)
        rampBar = seek(3, 30) { rampTxt?.text = "ออกตัว: ${it + 3}  (ต่ำ = เกาะพื้น, สูง = พุ่งแรง)" }.also { col.addView(it) }
        col.addView(button("บันทึกการออกตัว", GREEN) { send("A,${rampBar!!.progress + 3}") }, lp(-1, dp(46)))

        profBtn = button("ผังสาย", CYAN) { confirmProfile() }; col.addView(profBtn, lp(-1, dp(48)))
        col.addView(button("รีเซ็ตมอเตอร์", RED) { send("X") }, lp(-1, dp(48)))
        page(col)
        refreshSetup(); send("G")
    }

    private fun seek(min: Int, max: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max - min
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { onChange(v + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun updTrim() { trimTxt?.text = "ซ้าย ${(trimL?.progress ?: 0) + 50}%   ขวา ${(trimR?.progress ?: 0) + 50}%" }

    private fun cfgMotor(m: Int, flipSide: Boolean = false, flipInv: Boolean = false) {
        var s = cfg[4 + m]; var i = cfg[m]
        if (flipSide) s = 1 - s
        if (flipInv) i = 1 - i
        send("C,$m,$s,$i")
    }

    private fun refreshSetup() {
        if (screen != 2) return
        for (m in 0..3) {
            sideBtn[m]?.text = if (cfg[4 + m] == 1) "ข้าง: ขวา" else "ข้าง: ซ้าย"
            invBtn[m]?.text = if (cfg[m] == 1) "ทิศ: กลับ" else "ทิศ: ปกติ"
        }
        trimL?.progress = (cfg[8] - 50).coerceIn(0, 50); trimR?.progress = (cfg[9] - 50).coerceIn(0, 50)
        rampBar?.progress = (cfg[11] - 3).coerceIn(0, 27)
        profBtn?.text = "ผังสาย: ${if (cfg[10] == 1) "B (Fritzing)" else "A (เดิม)"}  — แตะเพื่อสลับ"
        updTrim()
    }

    private fun confirmProfile() {
        val to = 1 - cfg[10]
        AlertDialog.Builder(this).setMessage("สลับเป็นผังสาย ${if (to == 1) "B" else "A"} แล้วรีสตาร์ท ESP32 (บลูทูธจะหลุด)")
            .setPositiveButton("ตกลง") { _, _ -> send("P,$to") }.setNegativeButton("ยกเลิก", null).show()
    }

    // ---------- ความปลอดภัย ----------
    override fun onPause() {
        super.onPause()
        drive?.reset()
        if (connected) send("S")
    }

    override fun onDestroy() {
        stopScan(); ui.removeCallbacks(tick)
        if (connected) { send("S"); Thread.sleep(80) }
        session++; connected = false; closeSock()
        super.onDestroy()
    }
}
